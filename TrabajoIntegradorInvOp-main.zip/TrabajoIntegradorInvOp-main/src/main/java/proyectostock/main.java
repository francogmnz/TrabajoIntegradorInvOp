/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectostock;

import java.util.ArrayList;
import java.util.List;
import proyectostock.dtos.Main;
import proyectostock.entities.*;

/**
 *
 * @author Neri
 */
public class main {
    public static void main(String[] args) {
        
        Main objetoMain = new Main();
        objetoMain.setVisible(true);
    }
    
}
