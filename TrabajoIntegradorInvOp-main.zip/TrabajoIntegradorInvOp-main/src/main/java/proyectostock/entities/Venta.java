package proyectostock.entities;

import java.time.LocalDate;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 * Clase que representa una venta en el sistema.
 */
public class Venta {
    private LocalDate fechaVenta;
    private int numVenta;
    private int codArticulo; // Clave externa (foreign key) que referencia al código del artículo

    /**
     * Constructor de la clase Venta.
     * @param fechaVenta Fecha de la venta.
     * @param numVenta Número de la venta.
     * @param codArticulo Código del artículo vendido.
     */
    public Venta(LocalDate fechaVenta, int numVenta, int codArticulo) {
        this.fechaVenta = fechaVenta;
        this.numVenta = numVenta;
        this.codArticulo = codArticulo;
    }

    public Venta() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters y setters

    public LocalDate getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(LocalDate fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public int getNumVenta() {
        return numVenta;
    }

    public void setNumVenta(int numVenta) {
        this.numVenta = numVenta;
    }

    public int getCodArticulo() {
        return codArticulo;
    }

    public void setCodArticulo(int codArticulo) {
        this.codArticulo = codArticulo;
    }

    // Otros métodos, si los hay

    // Por ejemplo, podrías agregar métodos para calcular el total de la venta,
    // validar el código del artículo, etc.

    public void setNumeroVenta(String numeroVenta) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setFecha(String fecha) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public void SeleccionarArticuloVenta (JTable paramTablaArticulos, JTextField paramNombre) {

        try {
            int fila = paramTablaArticulos.getSelectedRow();

            if (fila >= 0) {
                paramNombre.setText(paramTablaArticulos.getValueAt(fila, 0).toString());
               
                //Falta el TipoArticulo
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione una fila");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de selección:" + e.toString());
        }

    }
    
}
